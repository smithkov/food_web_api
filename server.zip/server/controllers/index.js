const category = require("./category");

module.exports = {
  category,
};
