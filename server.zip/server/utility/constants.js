module.exports = {
    rootUrl : (path)=> `/api/${path}`,
    system: "SYSTEM",
    ACCESS_TOKEN :"access_token",
    REFRESH_TOKEN : "refresh_token"
}
